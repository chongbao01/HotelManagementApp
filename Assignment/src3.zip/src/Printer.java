public class Printer {
    public void printInfo(String name, String member_type, String room_type){
        System.out.println("Name: " + name);
        System.out.println("Member type:" + member_type);
        System.out.println("Room type:" + room_type);
    }
}
